# pyAroma
![](pyAroma_big.png)
*PyAroma* is a Python program for aromaticity analyses. Including ICSS, NICS, HOMA analyses tool.

# Update History
## v0.6 Pre-release, 2021-08-28
HOMA calculation module has been added into main program. Please refer to [*HOMAcalc*](https://github.com/wongzit/HOMAcalc) for user manual now.

## v0.3 Pre-release, 2021-08-28
First release of *PyAroma*. The user manual is under preparing, for now please refer to the user manual of [*ICSSgen*](https://github.com/wongzit/ICSSgen), [*ICSScsv*](https://github.com/wongzit/ICSScsv), [*ICSSgen3D*](https://github.com/wongzit/ICSSgen3D), [*ICSScub3D*](https://github.com/wongzit/ICSScub3D) and [*NICSgen*](https://github.com/wongzit/NICSgen).
